import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, LandmarkIcon, ExternalLink } from "lucide-react";
import { useState } from "react";

// Demo government services
const GOVERNMENT_SERVICES = [
  {
    id: 1,
    title: "Income Certificate Update",
    description: "Update your income details and get a new income certificate. Required for various government schemes and benefits.",
    category: "documentation",
    requirements: "Aadhar Card, Previous Income Certificate (if any), Bank Statements, Salary Slips",
    process: "Visit your nearest Common Service Center (CSC) with the required documents"
  },
  {
    id: 2,
    title: "Ration Card Update",
    description: "Modify your ration card details including family members, address, or apply for a new card.",
    category: "essential",
    requirements: "Aadhar Card, Proof of Address, Family Details, Recent Photographs",
    process: "Submit documents at your local PDS office or through online portal"
  },
  {
    id: 3,
    title: "Offline Scheme Application",
    description: "Get assistance with filling and submitting applications for various government schemes at your nearest center.",
    category: "schemes",
    requirements: "Basic ID Proof, Scheme-specific Documents",
    process: "Visit the designated government office or Common Service Center"
  }
];

export default function GovServices() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const filteredServices = selectedCategory === "all"
    ? GOVERNMENT_SERVICES
    : GOVERNMENT_SERVICES.filter(service => service.category === selectedCategory);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <LandmarkIcon className="h-6 w-6 text-primary" />
          <h2 className="text-2xl font-bold">Government Services</h2>
        </div>
        <Select
          value={selectedCategory}
          onValueChange={setSelectedCategory}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Services</SelectItem>
            <SelectItem value="documentation">Documentation</SelectItem>
            <SelectItem value="essential">Essential Services</SelectItem>
            <SelectItem value="schemes">Schemes</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-4">
        {filteredServices.map((service) => (
          <Card key={service.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{service.title}</CardTitle>
                <Badge>{service.category}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>{service.description}</p>

              <div className="bg-muted p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Requirements</h4>
                <p>{service.requirements}</p>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Process</h4>
                <p>{service.process}</p>
              </div>

              <Button asChild>
                <a href="#" target="_blank" rel="noopener noreferrer">
                  Schedule Appointment
                  <ExternalLink className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </CardContent>
          </Card>
        ))}

        {(!filteredServices || filteredServices.length === 0) && (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              <p>No services available for this category.</p>
              <p className="mt-2">Please check other categories or return later.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}