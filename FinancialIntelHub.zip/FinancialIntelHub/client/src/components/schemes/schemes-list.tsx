import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, ExternalLink } from "lucide-react";
import { useState } from "react";

// Demo schemes data from myscheme.gov.in
const SCHEMES = [
  {
    id: 1,
    title: "PM Kisan Samman Nidhi",
    description: "Direct income support of ₹6,000 per year to eligible farmer families in three equal installments.",
    category: "agriculture",
    eligibility: "All landholding farmer families with cultivable landholding in their names",
    link: "https://pmkisan.gov.in/",
  },
  {
    id: 2,
    title: "PM SVANidhi Scheme",
    description: "Micro credit facility that provides street vendors with collateral-free working capital loan up to ₹10,000.",
    category: "business",
    eligibility: "Street vendors engaged in vending in urban areas as on or before March 24, 2020",
    link: "https://pmsvanidhi.mohua.gov.in/",
  },
  {
    id: 3,
    title: "Sukanya Samriddhi Yojana",
    description: "Government-backed savings scheme for girl children with high interest rate and tax benefits.",
    category: "education",
    eligibility: "Parents/guardians of girl children below 10 years of age",
    link: "https://www.nsiindia.gov.in/InternalPage.aspx?Id_Pk=55",
  },
  {
    id: 4,
    title: "PM Jan Arogya Yojana",
    description: "Health insurance coverage of ₹5 lakh per family per year for secondary and tertiary care hospitalization.",
    category: "healthcare",
    eligibility: "Poor and vulnerable families as per SECC 2011 database",
    link: "https://pmjay.gov.in/",
  },
];

export default function SchemesList() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const filteredSchemes = selectedCategory === "all"
    ? SCHEMES
    : SCHEMES.filter(scheme => scheme.category === selectedCategory);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Government Schemes</h2>
        <Select
          value={selectedCategory}
          onValueChange={setSelectedCategory}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="agriculture">Agriculture</SelectItem>
            <SelectItem value="business">Small Business</SelectItem>
            <SelectItem value="education">Education</SelectItem>
            <SelectItem value="healthcare">Healthcare</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-6">
        {filteredSchemes?.map((scheme) => (
          <Card key={scheme.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle>{scheme.title}</CardTitle>
                <Badge>{scheme.category}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>{scheme.description}</p>

              <div className="bg-muted p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Eligibility Criteria</h4>
                <p>{scheme.eligibility}</p>
              </div>

              <Button asChild>
                <a href={scheme.link} target="_blank" rel="noopener noreferrer">
                  Apply Now
                  <ExternalLink className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}