import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bell, Loader2, MapPin, Clock } from "lucide-react";

const ALERTS = [
  {
    id: 1,
    title: "Fake KYC Update Scam",
    description: "Fraudsters are calling citizens pretending to be bank officials asking for KYC updates. They ask for OTP or account details. Remember: Banks never ask for OTP or full card details over phone.",
    location: "Pan India",
    timestamp: "2024-02-16",
    active: true,
  },
  {
    id: 2,
    title: "UPI Fraud Alert",
    description: "New scam detected where fraudsters pose as buyers on online marketplaces and send fake UPI payment screenshots. Always verify that money is credited to your account before proceeding.",
    location: "Major Cities",
    timestamp: "2024-02-15",
    active: true,
  },
  {
    id: 3,
    title: "Loan App Warning",
    description: "Multiple cases reported of fake loan apps charging excessive processing fees and harassing borrowers. Only use RBI registered apps for loans. Check RBI's official website for legitimate apps.",
    location: "Maharashtra, Delhi",
    timestamp: "2024-02-14",
    active: true,
  }
];

export default function FraudAlerts() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Bell className="h-6 w-6 text-destructive" />
        <h2 className="text-2xl font-bold">Fraud Alerts</h2>
      </div>

      <div className="grid gap-4">
        {ALERTS.map((alert) => (
          <Card key={alert.id}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg text-destructive">
                  {alert.title}
                </CardTitle>
                <Badge variant={alert.active ? "destructive" : "secondary"}>
                  {alert.active ? "Active Threat" : "Resolved"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>{alert.description}</p>

              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                {alert.location && (
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span>{alert.location}</span>
                  </div>
                )}
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  <span>{new Date(alert.timestamp).toLocaleDateString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}