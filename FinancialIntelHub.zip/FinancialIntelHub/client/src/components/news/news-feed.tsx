import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, ThumbsUp, IndianRupee, TrendingUp, AlertTriangle, Newspaper } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import ImpactGraph from "./impact-graph";

type NewsAnalysis = {
  summary: string;
  impact: string[];
  actions: string[];
  relevanceScore: number;
};

const SAMPLE_NEWS = [
  {
    title: "Government Announces 7% Increase in Nitrogen Fertilizer Taxation",
    description: "The Ministry of Agriculture has announced a 7% increase in taxation on nitrogen-based fertilizers, effective from April 1st, 2024. This measure aims to promote sustainable farming practices and reduce environmental impact.",
    url: "news-1",
    publishedAt: "2024-02-16T08:00:00Z"
  },
  {
    title: "New Minimum Support Price (MSP) for Rabi Crops Announced",
    description: "Cabinet approves higher MSP for wheat (₹2,275/quintal) and pulses (₹4,800/quintal) for the 2024-25 marketing season. This represents a 5.5% increase to support farmer incomes.",
    url: "news-2",
    publishedAt: "2024-02-15T09:30:00Z"
  },
  {
    title: "RBI Announces Special Rural Credit Scheme",
    description: "Reserve Bank introduces new credit scheme for small and marginal farmers, offering loans at 4% interest rate for agricultural inputs. Applications open March 1st, 2024.",
    url: "news-3",
    publishedAt: "2024-02-14T11:00:00Z"
  },
  {
    title: "Major Changes in PMFBY Crop Insurance Scheme",
    description: "Premium subsidies increased by 10% for small farmers under Pradhan Mantri Fasal Bima Yojana. New coverage options added for climate-related crop damages.",
    url: "news-4",
    publishedAt: "2024-02-13T14:20:00Z"
  }
];

export default function NewsFeed() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedArticle, setSelectedArticle] = useState<string | null>(null);

  const { data: articles, isLoading } = useQuery({
    queryKey: ["news"],
    queryFn: async () => SAMPLE_NEWS,
  });

  const analysisMutation = useMutation({
    mutationFn: async (text: string) => {
      const res = await apiRequest("POST", "/api/analyze-news", { text });
      return res.json() as Promise<NewsAnalysis>;
    },
    onError: (error) => {
      toast({
        title: "Analysis failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <Newspaper className="h-8 w-8 text-primary" />
        <h2 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Personalized Financial News
        </h2>
      </div>

      <div className="grid gap-6">
        {articles?.map((article) => (
          <Card 
            key={article.url} 
            className="overflow-hidden transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 group"
          >
            <CardHeader className="space-y-2 bg-gradient-to-r from-background to-muted">
              <div className="space-y-2">
                <CardTitle className="text-xl font-bold group-hover:text-primary transition-colors">
                  {article.title}
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  {new Date(article.publishedAt).toLocaleDateString(undefined, {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
              </div>
            </CardHeader>
            <CardContent className="space-y-6 pt-4">
              <p className="text-muted-foreground leading-relaxed">{article.description}</p>

              {selectedArticle === article.url && analysisMutation.data && (
                <div className="mt-6 space-y-6 animate-in fade-in-50 duration-500">
                  <div className="p-6 bg-gradient-to-b from-muted/50 to-muted rounded-lg space-y-6 border shadow-sm">
                    <div className="pb-4 border-b">
                      <h4 className="font-semibold mb-2 flex items-center text-lg">
                        <AlertTriangle className="h-5 w-5 text-primary mr-2" />
                        Key Impact Summary
                      </h4>
                      <p className="text-lg leading-relaxed">{analysisMutation.data.summary}</p>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-semibold flex items-center text-lg">
                        <IndianRupee className="h-5 w-5 text-primary mr-2" />
                        Financial Impact Projection
                      </h4>
                      <div className="bg-background rounded-lg p-4 shadow-inner">
                        <ImpactGraph
                          summary={analysisMutation.data.summary}
                          impact={analysisMutation.data.impact}
                          startDate={new Date()}
                        />
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-4 flex items-center text-lg">
                        <TrendingUp className="h-5 w-5 text-primary mr-2" />
                        Recommended Actions
                      </h4>
                      <ul className="space-y-3 pl-4">
                        {analysisMutation.data.actions.map((action, i) => (
                          <li key={i} className="flex items-start group/item">
                            <span className="text-primary mr-2 transition-transform group-hover/item:scale-110">•</span>
                            <span className="leading-relaxed">{action}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="pt-4 border-t flex items-center gap-2 text-muted-foreground">
                      <ThumbsUp className="h-4 w-4" />
                      <span>
                        {Math.round(analysisMutation.data.relevanceScore * 100)}% relevant to your profile
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {!selectedArticle || selectedArticle !== article.url ? (
                <Button
                  onClick={() => {
                    setSelectedArticle(article.url);
                    analysisMutation.mutate(article.title + " " + article.description);
                  }}
                  disabled={analysisMutation.isPending}
                  className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 transition-all duration-300"
                >
                  {analysisMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing Impact...
                    </>
                  ) : (
                    "Analyze Personal Impact"
                  )}
                </Button>
              ) : null}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}