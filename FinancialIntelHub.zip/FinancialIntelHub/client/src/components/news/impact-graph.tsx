import { useEffect, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Area,
  AreaChart,
} from "recharts";
import { Card } from "@/components/ui/card";

type TimelineDataPoint = {
  month: string;
  value: number;
  baseline: number;
};

type ImpactGraphProps = {
  summary: string;
  impact: string[];
  startDate?: Date;
};

export default function ImpactGraph({ summary, impact, startDate = new Date() }: ImpactGraphProps) {
  const [data, setData] = useState<TimelineDataPoint[]>([]);
  const [isAnimating, setIsAnimating] = useState(true);

  useEffect(() => {
    // Parse impact strings to extract numerical values
    const impactValue = parseImpactValue(impact[0]);
    const percentageChange = parsePercentageChange(impact[1]);

    // Generate 12 months of data
    const timelineData = generateTimelineData(
      startDate,
      impactValue,
      percentageChange
    );

    setData([]);
    setIsAnimating(true);

    // Animate data points one by one
    timelineData.forEach((point, index) => {
      setTimeout(() => {
        setData(prev => [...prev, point]);
        if (index === timelineData.length - 1) {
          setIsAnimating(false);
        }
      }, index * 200); // 200ms delay between each point
    });
  }, [summary, impact, startDate]);

  const isPositiveImpact = data[0]?.value > data[0]?.baseline;

  return (
    <Card className="p-4 bg-gradient-to-b from-background to-background/50">
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={data}
            margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
          >
            <defs>
              <linearGradient id="positiveGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="rgb(34, 197, 94)" stopOpacity={0.3} />
                <stop offset="100%" stopColor="rgb(34, 197, 94)" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="negativeGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="rgb(239, 68, 68)" stopOpacity={0.3} />
                <stop offset="100%" stopColor="rgb(239, 68, 68)" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="baselineGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="rgb(156, 163, 175)" stopOpacity={0.2} />
                <stop offset="100%" stopColor="rgb(156, 163, 175)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis 
              dataKey="month" 
              tick={{ fontSize: 12 }}
              stroke="hsl(var(--muted-foreground))"
            />
            <YAxis
              tick={{ fontSize: 12 }}
              tickFormatter={(value) => `₹${value.toLocaleString()}`}
              stroke="hsl(var(--muted-foreground))"
            />
            <Tooltip
              formatter={(value: number) => [`₹${value.toLocaleString()}`, "Amount"]}
              contentStyle={{
                backgroundColor: "hsl(var(--background))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "0.5rem",
                padding: "0.5rem",
              }}
              itemStyle={{ color: "hsl(var(--foreground))" }}
            />
            <ReferenceLine
              y={0}
              stroke="hsl(var(--muted-foreground))"
              strokeDasharray="3 3"
            />
            <Area
              type="monotone"
              dataKey="baseline"
              stroke="hsl(var(--muted-foreground))"
              fillOpacity={1}
              fill="url(#baselineGradient)"
              strokeDasharray="3 3"
              strokeWidth={1.5}
            />
            <Area
              type="monotone"
              dataKey="value"
              stroke={isPositiveImpact ? "rgb(34, 197, 94)" : "rgb(239, 68, 68)"}
              fillOpacity={1}
              fill={`url(#${isPositiveImpact ? 'positiveGradient' : 'negativeGradient'})`}
              strokeWidth={2}
              isAnimationActive={true}
              animationDuration={1000}
              animationBegin={0}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}

// Helper functions to parse impact data
function parseImpactValue(impactStr: string): number {
  const match = impactStr.match(/₹([\d,]+)/);
  if (!match) return 0;
  return parseInt(match[1].replace(/,/g, ''));
}

function parsePercentageChange(impactStr: string): number {
  const match = impactStr.match(/(\d+(?:\.\d+)?)%/);
  if (!match) return 0;
  return parseFloat(match[1]) / 100;
}

function generateTimelineData(
  startDate: Date,
  impactValue: number,
  percentageChange: number
): TimelineDataPoint[] {
  const months = [];
  const baselineValue = impactValue / (1 + percentageChange);

  for (let i = 0; i < 12; i++) {
    const date = new Date(startDate);
    date.setMonth(date.getMonth() + i);
    const month = date.toLocaleString('default', { month: 'short' });

    // For demonstration, we'll show a gradual change over time
    const progressFactor = Math.min(1, (i + 1) / 3); // Change takes effect over 3 months
    const currentValue = baselineValue + (impactValue - baselineValue) * progressFactor;

    months.push({
      month,
      value: Math.round(currentValue),
      baseline: Math.round(baselineValue)
    });
  }

  return months;
}