import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Loader2, Building2 } from "lucide-react";

// For demo purposes, we'll hardcode the fintech partners
const FINTECH_PARTNERS = [
  {
    id: 1,
    name: "pSwitch",
    type: "fintech",
    description: "Providing doorstep banking services to promote financial inclusion in rural India. Services include domestic cash transfer, cash withdrawals, prepaid cards, travel booking, and government services like eDistrict.",
    services: "Digital Banking, Government Services, Financial Inclusion",
    status: "approved"
  },
  {
    id: 2,
    name: "FIA Global",
    type: "fintech",
    description: "An AI-powered financial inclusion platform that delivers customized financial products to low-income customers through a network of 25,000 inclusion centres.",
    services: "AI Financial Planning, Digital Banking, Financial Products",
    status: "approved"
  },
  {
    id: 3,
    name: "Jai Kisan",
    type: "fintech",
    description: "Empowering rural commerce with digital financial services, specializing in credit solutions for online and income-generating rural transactions.",
    services: "Rural Credit, Digital Financial Services",
    status: "approved"
  }
];

export default function FinancialHelp() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Building2 className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-bold">Financial Services</h2>
      </div>

      <div className="grid gap-4">
        {FINTECH_PARTNERS.map((partner) => (
          <Card key={partner.id} className="group hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl">{partner.name}</CardTitle>
                  <div className="flex gap-2 mt-2">
                    {partner.services.split(", ").map((service, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {service}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">{partner.description}</p>

              <div className="flex flex-wrap gap-4">
                <Button className="group-hover:bg-primary/90">
                  Apply Now
                  <ExternalLink className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}