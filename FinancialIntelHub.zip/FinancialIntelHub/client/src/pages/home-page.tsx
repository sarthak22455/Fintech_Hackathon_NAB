import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import ProfileForm from "@/components/ui/profile-form";
import NewsFeed from "@/components/news/news-feed";
import FinancialHelp from "@/components/financial/financial-help";
import GovServices from "@/components/gov/gov-services";
import SchemesList from "@/components/schemes/schemes-list";
import PartnerOnboarding from "@/components/partners/partner-onboarding";
import FraudAlerts from "@/components/alerts/fraud-alerts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LogOut } from "lucide-react";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();

  // If user hasn't completed their profile, show the profile form
  if (!user?.employmentStatus) {
    return (
      <div className="container mx-auto p-8">
        <h1 className="text-2xl font-bold mb-6">Complete Your Profile</h1>
        <ProfileForm />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-bold">FinBridge</h1>
            <Badge variant="outline" className="ml-2">
              {user.points} points
            </Badge>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="financial" className="space-y-8">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="financial">Financial Help</TabsTrigger>
            <TabsTrigger value="schemes">Government Schemes</TabsTrigger>
            <TabsTrigger value="services">Government Services</TabsTrigger>
            <TabsTrigger value="news">News Feed</TabsTrigger>
            <TabsTrigger value="alerts">Fraud Alerts</TabsTrigger>
            <TabsTrigger value="partners">Partner Portal</TabsTrigger>
          </TabsList>

          <TabsContent value="financial">
            <Card>
              <CardContent className="p-6">
                <FinancialHelp />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="schemes">
            <Card>
              <CardContent className="p-6">
                <SchemesList />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="services">
            <Card>
              <CardContent className="p-6">
                <GovServices />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="news">
            <Card>
              <CardContent className="p-6">
                <NewsFeed />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alerts">
            <Card>
              <CardContent className="p-6">
                <FraudAlerts />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="partners">
            <Card>
              <CardContent className="p-6">
                <PartnerOnboarding />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}