import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  employmentStatus: text("employment_status"),
  income: integer("income"),
  location: text("location"),
  dailyActivity: text("daily_activity"),
  points: integer("points").default(0),
});

export const schemes = pgTable("schemes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  eligibility: text("eligibility").notNull(),
  link: text("link").notNull(),
});

export const partners = pgTable("partners", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  services: text("services").notNull(),
  status: text("status").default("pending"),
});

export const fraudAlerts = pgTable("fraud_alerts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location"),
  timestamp: text("timestamp").notNull(),
  active: boolean("active").default(true),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const updateProfileSchema = createInsertSchema(users).pick({
  employmentStatus: true,
  income: true,
  location: true,
  dailyActivity: true,
});

export const insertPartnerSchema = createInsertSchema(partners);
export const insertSchemeSchema = createInsertSchema(schemes);
export const insertFraudAlertSchema = createInsertSchema(fraudAlerts);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpdateProfile = z.infer<typeof updateProfileSchema>;
export type InsertPartner = z.infer<typeof insertPartnerSchema>;
export type InsertScheme = z.infer<typeof insertSchemeSchema>;
export type InsertFraudAlert = z.infer<typeof insertFraudAlertSchema>;

export type User = typeof users.$inferSelect;
export type Partner = typeof partners.$inferSelect;
export type Scheme = typeof schemes.$inferSelect;
export type FraudAlert = typeof fraudAlerts.$inferSelect;
