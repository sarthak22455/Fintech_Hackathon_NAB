import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import {
  updateProfileSchema,
  insertPartnerSchema,
  insertSchemeSchema,
  insertFraudAlertSchema,
} from "@shared/schema";
import { analyzeNewsImpact } from "./gemini";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Profile routes
  app.patch("/api/profile", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const result = updateProfileSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const updatedUser = await storage.updateUserProfile(req.user.id, result.data);
    res.json(updatedUser);
  });

  // Partner routes
  app.post("/api/partners", async (req, res) => {
    const result = insertPartnerSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const partner = await storage.createPartner(result.data);
    res.status(201).json(partner);
  });

  app.get("/api/partners", async (_req, res) => {
    const partners = await storage.getPartners();
    res.json(partners);
  });

  // Scheme routes
  app.post("/api/schemes", async (req, res) => {
    const result = insertSchemeSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const scheme = await storage.createScheme(result.data);
    res.status(201).json(scheme);
  });

  app.get("/api/schemes", async (_req, res) => {
    const schemes = await storage.getSchemes();
    res.json(schemes);
  });

  // Fraud alert routes
  app.post("/api/fraud-alerts", async (req, res) => {
    const result = insertFraudAlertSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json(result.error);
    }

    const alert = await storage.createFraudAlert(result.data);
    res.status(201).json(alert);
  });

  app.get("/api/fraud-alerts", async (_req, res) => {
    const alerts = await storage.getFraudAlerts();
    res.json(alerts);
  });

  // News analysis route
  app.post("/api/analyze-news", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: "Text is required" });

    try {
      const analysis = await analyzeNewsImpact(text, req.user);
      res.json(analysis);
    } catch (error) {
      console.error("News analysis error:", error);
      res.status(500).json({ error: "Failed to analyze news" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}