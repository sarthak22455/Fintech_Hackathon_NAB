import { GoogleGenerativeAI } from "@google/generative-ai";
import { User } from "@shared/schema";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

export async function analyzeNewsImpact(text: string, user: User) {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });

    const prompt = `
    As a financial impact analyst for rural India, analyze this news for a person with these characteristics:
    - Employment: ${user.employmentStatus || 'Unknown'}
    - Income Level: ${user.income ? `₹${user.income}/year` : 'Unknown'}
    - Location: ${user.location || 'Unknown'}
    - Daily Activity: ${user.dailyActivity || 'Unknown'}

    News text:
    ${text}

    Focus on direct financial impacts. For example:
    - If news is about nitrogen/fertilizer taxation and user is a farmer, calculate direct cost increase per month
    - If news is about labor law changes and user is a daily wage worker, calculate wage impact percentage
    - If news is about MSP changes and user is a farmer, calculate income impact
    - If news is about business registration fees and user is a small business owner, calculate cost impact

    Provide analysis in JSON format with these fields:
    {
      "summary": "One clear sentence about direct financial impact",
      "impact": [
        "Direct financial impact in Rupees with exact numbers",
        "Percentage change in costs/income",
        "Timeline for the impact"
      ],
      "actions": [
        "Apply for specific subsidy X to offset costs",
        "Take advantage of scheme Y for support",
        "Specific action steps with deadlines"
      ],
      "relevanceScore": 0.95 // High if directly affects user's sector
    }

    Rules:
    1. All monetary values must be in ₹ (INR)
    2. Give specific numbers and percentages
    3. Only calculate direct impacts based on user's profile
    4. For farmers, focus on input costs and MSP
    5. For laborers, focus on wage changes
    6. For small business owners, focus on operational costs
    7. Link to relevant government schemes when available

    Example Output for a farmer and fertilizer news:
    {
      "summary": "The 7% increase in nitrogen fertilizer tax will raise your monthly fertilizer costs by ₹850",
      "impact": [
        "Monthly fertilizer expense will increase from ₹12,000 to ₹12,850",
        "7% increase in input costs from April 1st, 2024",
        "Annual impact of ₹10,200 on your farming expenses"
      ],
      "actions": [
        "Apply for PM-KISAN's next installment of ₹2,000 by March 31st",
        "Buy and stock fertilizers before April 1st to save ₹850/month",
        "Register for soil health card to optimize fertilizer usage"
      ],
      "relevanceScore": 0.95
    }`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const textResponse = response.text();

    // Extract JSON from the response
    const jsonStr = textResponse.match(/\{[\s\S]*\}/)?.[0] || "{}";
    return JSON.parse(jsonStr);

  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error("Failed to analyze news impact");
  }
}