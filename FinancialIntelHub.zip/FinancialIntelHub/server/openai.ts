import OpenAI from "openai";
import { User } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function analyzeNewsImpact(text: string, user: User) {
  try {
    const prompt = `
    As a financial impact analyst for rural India, analyze this news for a person with these characteristics:
    - Employment: ${user.employmentStatus || 'Unknown'}
    - Income Level: ${user.income ? `₹${user.income}/year` : 'Unknown'}
    - Location: ${user.location || 'Unknown'}
    - Daily Activity: ${user.dailyActivity || 'Unknown'}

    News text:
    ${text}

    Focus on direct financial impacts. For example:
    - If news is about nitrogen taxation and user is a farmer, calculate direct fertilizer cost increase
    - If news is about labor law changes and user is a laborer, calculate wage impact percentage

    Provide analysis in JSON format with these fields:
    {
      "summary": "One clear sentence about direct financial impact",
      "impact": [
        "Direct financial impact in Rupees",
        "Percentage change in costs/income",
        "Timeline for the impact"
      ],
      "actions": [
        "Apply for specific subsidy X",
        "Take advantage of scheme Y"
      ],
      "relevanceScore": 0.95 // High if directly affects user's sector
    }

    Make all monetary values in ₹ (INR).
    Be specific with numbers and percentages.
    Only calculate direct impacts based on user's profile.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are a financial impact analyst for rural India" },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });

    return JSON.parse(response.choices[0].message.content);

  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to analyze news impact");
  }
}