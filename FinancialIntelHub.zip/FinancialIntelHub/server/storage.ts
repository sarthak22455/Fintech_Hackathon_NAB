import { IStorage } from "./storage.types";
import {
  User,
  Partner,
  Scheme,
  FraudAlert,
  InsertUser,
  InsertPartner,
  InsertScheme,
  InsertFraudAlert,
  UpdateProfile,
  users,
  partners,
  schemes,
  fraudAlerts,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  public sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values({
        ...user,
        points: 0,
        employmentStatus: null,
        income: null,
        location: null,
        dailyActivity: null,
      })
      .returning();
    return newUser;
  }

  async updateUserProfile(id: number, profile: UpdateProfile): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set(profile)
      .where(eq(users.id, id))
      .returning();

    if (!updatedUser) {
      throw new Error("User not found");
    }

    return updatedUser;
  }

  async createPartner(partner: InsertPartner): Promise<Partner> {
    const [newPartner] = await db
      .insert(partners)
      .values(partner)
      .returning();
    return newPartner;
  }

  async getPartners(): Promise<Partner[]> {
    return await db.select().from(partners);
  }

  async createScheme(scheme: InsertScheme): Promise<Scheme> {
    const [newScheme] = await db
      .insert(schemes)
      .values(scheme)
      .returning();
    return newScheme;
  }

  async getSchemes(): Promise<Scheme[]> {
    return await db.select().from(schemes);
  }

  async createFraudAlert(alert: InsertFraudAlert): Promise<FraudAlert> {
    const [newAlert] = await db
      .insert(fraudAlerts)
      .values(alert)
      .returning();
    return newAlert;
  }

  async getFraudAlerts(): Promise<FraudAlert[]> {
    return await db.select().from(fraudAlerts);
  }
}

export const storage = new DatabaseStorage();